﻿using Microsoft.AspNetCore.Mvc;
using MUNDOGUTS.Models;
using MUNDOGUTS.DAL.USUARIO;
namespace MUNDOGUTS.Controllers
{




    namespace MUNDOGUTS.Controllers
    {
        public class Usuario : Controller
        {
            [HttpGet]
            public IActionResult Cadastra()
            {
                return View(new ObjUsuario());
            }

            [HttpPost]
            public IActionResult Cadastra(ObjUsuario objUsuario)
            {
                USUARIOSDAL dal = new();
                dal.Cadastrar(objUsuario);

                return View(objUsuario);
            }
        }
    }
}