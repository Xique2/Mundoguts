﻿using Microsoft.AspNetCore.Mvc;
using MUNDOGUTS.DAL.USUARIO;
using MUNDOGUTS.Models;
namespace MUNDOGUTS.Controllers
{
    public class Buscar : Controller
    {
        public IActionResult Bus()
        {
            ObjUsuario objUsuario = new();
            DAL.USUARIO.USUARIOSDAL dal = new();
            dal.BUSCARUSER(objUsuario);

            return View(objUsuario);
        }
    }
}
