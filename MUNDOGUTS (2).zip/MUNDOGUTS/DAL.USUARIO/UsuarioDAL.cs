﻿using Microsoft.Data.SqlClient;

namespace MUNDOGUTS.DAL.USUARIO
{




        public class USUARIOSDAL
        {





            public  void Cadastrar (ObjUsuario user)
            {
                string sql = $"INSERT INTO TbUsuario (NomeUsuario,SenhaHash )VALUES (@USER,@SENHA)";
                SqlConnection conn = new("Server=tcp:cmg-sql-dev-phl2026.database.windows.net,1433;Initial Catalog=SIGE_DB;Persist Security Info=False;User ID=dbadmin_sige;Password=Mundo@2026#Fund1X;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;");
                conn.Open();
                SqlCommand cmd = new(sql, conn);
                cmd.Parameters.AddWithValue("@USER", user.Nome);
                cmd.Parameters.AddWithValue("@SENHA", user.Senha);
                cmd.ExecuteNonQuery();
            //CONfERIDO 
           
            }
            public void Delete (ObjUsuario user)
            {

                string sql = $"DELETE FROM TbUsuario WHERE IdUsuario = @USER";
                SqlConnection conn = new("Server=tcp:cmg-sql-dev-phl2026.database.windows.net,1433;Initial Catalog=SIGE_DB;Persist Security Info=False;User ID=dbadmin_sige;Password=Mundo@2026#Fund1X;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;");
                conn.Open();
                SqlCommand cmd = new(sql, conn);
                cmd.Parameters.AddWithValue("@USER", user.IdUsuario);
                cmd.ExecuteNonQuery();
                //CONfERIDO
            }
            public void UpDateUser(ObjUsuario user)
            {
                SqlConnection conn = new("Server=tcp:cmg-sql-dev-phl2026.database.windows.net,1433;Initial Catalog=SIGE_DB;Persist Security Info=False;User ID=dbadmin_sige;Password=Mundo@2026#Fund1X;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;");
                conn.Open();
                string sql = "UPDATE TbUsuario SET NomeUsuario=@USER, SenhaHash=@SENHA WHERE IdUsuario=@IDUSER";
                SqlCommand cmd = new(sql, conn);
                cmd.Parameters.AddWithValue("@USER", user.Nome);
                cmd.Parameters.AddWithValue("@SENHA", user.Senha);
                cmd.Parameters.AddWithValue("@IDUSER", user.IdUsuario);
                cmd.ExecuteNonQuery();
                //CONfERIDO
            }
            public void BUSCARUSER(ObjUsuario user)
            {
                List<ObjUsuario> Listauser = new();
                SqlConnection conn = new("Server=tcp:cmg-sql-dev-phl2026.database.windows.net,1433;Initial Catalog=SIGE_DB;Persist Security Info=False;User ID=dbadmin_sige;Password=Mundo@2026#Fund1X;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;");
                conn.Open();
                string sql = $"SELECT * FROM TbUsuario WHERE IdUsuario = @IDUSER";
                SqlCommand cmd = new(sql, conn);
                cmd.Parameters.AddWithValue("@IDUSER", user.IdUsuario);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                  Listauser.Add(new ObjUsuario
                    {
                         Nome = dr["NomeUsuario"].ToString(),
                         Senha = dr["SenhaHash"].ToString(),


                    });

                }

            }



















































































        }
    
    
}