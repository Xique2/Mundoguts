﻿namespace MUNDOGUTS.DAL.USUARIO
{



   public class   ObjUsuario
    {
        public int IdUsuario  { get; set; } 
        public string Nome{ get; set; }
        public string Senha { get; set; }
        public string STATUS { get; set; }
        public int IDPERFIL { get; set; }
    }
}